# SensorHub — Architecture

Clean Architecture, .NET 8. Core platform is sensor-type agnostic (temperature,
soil moisture, GPS, RFID, PLC, smart meter, vibration, water level, air quality).

## Layers

- **Domain** — entities and business rules (`Sensor`, `SensorReading`, `Tenant`). No dependencies.
- **Application** — use cases / service interfaces (`ISensorService`). Depends on Domain + Shared.
- **Infrastructure** — persistence (EF Core `SensorHubDbContext`), MQTT client. Depends on Application.
- **Api** — REST endpoints (`SensorsController`). Depends on Application + Infrastructure.
- **Worker** — background service that listens to MQTT, persists readings, runs alert rules.
- **Web** — Blazor Server dashboard (live charts, maps, alerts).
- **Shared** — DTOs shared between Api, Web, and Mobile clients.
- **DeviceSimulator** — publishes fake sensor data to MQTT for local dev/demo without hardware.

## Data flow

```
Sensor → MQTT Broker → Worker Service → Database → REST API → Dashboard / Alerts
```

## Status

Folder structure and stub files only — no implementations yet. Every stub throws
`NotImplementedException` or is marked `TODO`. Next steps to make this buildable:

1. Add EF Core + a provider (Postgres/SQL Server) to Infrastructure, implement `SensorHubDbContext`.
2. Add MQTTnet to Infrastructure, implement `MqttClientService`.
3. Implement `SensorService` against the DbContext.
4. Wire DI in `SensorHub.Api/Program.cs` and `SensorHub.Worker/Program.cs`.
5. Flesh out the Blazor dashboard and SignalR hub for live updates.
