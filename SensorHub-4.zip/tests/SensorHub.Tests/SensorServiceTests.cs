using Xunit;

namespace SensorHub.Tests;

public class SensorServiceTests
{
    [Fact]
    public void Placeholder_ReplaceWithRealTests()
    {
        // TODO: test sensor registration, reading ingestion, alert thresholds
        Assert.True(true);
    }
}
