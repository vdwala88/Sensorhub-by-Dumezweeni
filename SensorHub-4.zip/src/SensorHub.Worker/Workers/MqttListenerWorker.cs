namespace SensorHub.Worker.Workers;

/// <summary>
/// Background service that listens on the MQTT broker for incoming sensor
/// messages, persists readings, and evaluates alert rules (e.g. "Soil &lt; 30%").
/// TODO: implement.
/// </summary>
public class MqttListenerWorker : BackgroundService
{
    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        throw new NotImplementedException();
    }
}
