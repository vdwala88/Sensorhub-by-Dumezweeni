using SensorHub.Worker.Workers;

var builder = Host.CreateApplicationBuilder(args);

// TODO: register MqttClientService, ISensorService, alert rule engine
builder.Services.AddHostedService<MqttListenerWorker>();

var host = builder.Build();
host.Run();
