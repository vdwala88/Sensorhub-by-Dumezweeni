using SensorHub.Application.Interfaces;
using SensorHub.Domain.Entities;

namespace SensorHub.Application.Services;

public class SensorService : ISensorService
{
    // TODO: inject a repository/DbContext from Infrastructure once wired up

    public Task<IEnumerable<Sensor>> GetAllAsync(Guid tenantId)
        => throw new NotImplementedException();

    public Task<Sensor?> GetByIdAsync(Guid sensorId)
        => throw new NotImplementedException();

    public Task<Sensor> RegisterAsync(Sensor sensor)
        => throw new NotImplementedException();

    public Task RecordReadingAsync(Guid sensorId, double value, DateTime timestamp)
        => throw new NotImplementedException();
}
