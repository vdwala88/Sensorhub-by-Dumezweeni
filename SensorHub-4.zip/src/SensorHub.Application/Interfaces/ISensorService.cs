using SensorHub.Domain.Entities;

namespace SensorHub.Application.Interfaces;

public interface ISensorService
{
    // TODO: implement — CRUD + latest-reading lookups for a tenant's sensors
    Task<IEnumerable<Sensor>> GetAllAsync(Guid tenantId);
    Task<Sensor?> GetByIdAsync(Guid sensorId);
    Task<Sensor> RegisterAsync(Sensor sensor);
    Task RecordReadingAsync(Guid sensorId, double value, DateTime timestamp);
}
