// Generates fake sensor readings (soil moisture, temperature, GPS, etc.)
// and publishes them to the MQTT broker so the platform can be developed
// and demoed without real hardware.
//
// TODO: implement — read a config of simulated sensors, loop on an
// interval, publish JSON payloads via MQTTnet client.

Console.WriteLine("SensorHub.DeviceSimulator — not yet implemented");
