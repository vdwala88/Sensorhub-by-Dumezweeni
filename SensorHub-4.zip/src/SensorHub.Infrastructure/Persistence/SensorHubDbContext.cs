namespace SensorHub.Infrastructure.Persistence;

/// <summary>
/// EF Core DbContext stub. TODO: inherit DbContext, add DbSet&lt;Sensor&gt;,
/// DbSet&lt;SensorReading&gt;, DbSet&lt;Tenant&gt; once EF Core is added as
/// a dependency, and configure tenant-scoped query filters.
/// </summary>
public class SensorHubDbContext
{
    // TODO: implement
}
