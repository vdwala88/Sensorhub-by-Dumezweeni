namespace SensorHub.Infrastructure.Mqtt;

/// <summary>
/// Wraps the MQTT broker connection. TODO: implement using MQTTnet —
/// subscribe to sensor topics, deserialize payloads, and hand off to
/// the Application layer for processing.
/// </summary>
public class MqttClientService
{
    public Task ConnectAsync() => throw new NotImplementedException();
    public Task SubscribeAsync(string topic) => throw new NotImplementedException();
}
