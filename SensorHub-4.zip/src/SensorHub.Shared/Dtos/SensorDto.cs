namespace SensorHub.Shared.Dtos;

/// <summary>
/// Shape returned by the API / consumed by Web and Mobile clients.
/// </summary>
public record SensorDto(
    Guid Id,
    string Name,
    string Location,
    string Type,
    bool IsActive
);

public record SensorReadingDto(
    Guid SensorId,
    double Value,
    DateTime Timestamp
);
