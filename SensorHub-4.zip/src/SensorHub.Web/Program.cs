var builder = WebApplication.CreateBuilder(args);

// TODO: add Blazor Server services, SignalR hub for live sensor updates
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
