using Microsoft.AspNetCore.Mvc;

namespace SensorHub.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SensorsController : ControllerBase
{
    // TODO: inject ISensorService and implement CRUD + reading ingestion endpoints

    [HttpGet]
    public IActionResult GetAll()
    {
        throw new NotImplementedException();
    }

    [HttpGet("{id:guid}")]
    public IActionResult GetById(Guid id)
    {
        throw new NotImplementedException();
    }

    [HttpPost]
    public IActionResult Register()
    {
        throw new NotImplementedException();
    }

    [HttpPost("{id:guid}/readings")]
    public IActionResult RecordReading(Guid id)
    {
        throw new NotImplementedException();
    }
}
